import React, { useState } from 'react'

type Msg = { from: 'user'|'bot'; text: string; agent?: string }

const API = (import.meta.env.VITE_API_URL as string) || 'http://localhost:8080'

export default function App() {
  const [conversationId, setConv] = useState('conv-1234')
  const [userId, setUser] = useState('client789')
  const [input, setInput] = useState('')
  const [msgs, setMsgs] = useState<Msg[]>([])
  const [loading, setLoading] = useState(false)

  async function send() {
    if (!input.trim()) return
    const payload = { message: input, user_id: userId, conversation_id: conversationId }
    setMsgs(m => [...m, { from: 'user', text: input }])
    setInput('')
    setLoading(true)
    try {
      const res = await fetch(`${API}/chat`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      })
      const data = await res.json()
      setMsgs(m => [
        ...m,
        { from: 'bot', text: data.response, agent: data.agent_workflow?.at(-1)?.agent || '?' }
      ])
    } catch (e: any) {
      setMsgs(m => [...m, { from: 'bot', text: 'Erro ao enviar mensagem.' }])
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="container">
      <h2>Modular Chatbot</h2>
      <div className="card">
        <div className="row">
          <input value={conversationId} onChange={e=>setConv(e.target.value)} placeholder="conversation_id" style={{flex: 1}} />
          <input value={userId} onChange={e=>setUser(e.target.value)} placeholder="user_id" style={{flex: 1}} />
        </div>
        <div className="history">
          {msgs.map((m, i) => (
            <div className="msg" key={i}>
              <span className="who">{m.from === 'user' ? 'Você' : 'Bot'}</span>
              {m.agent ? <span className="badge">{m.agent}</span> : null}
              <div>{m.text}</div>
            </div>
          ))}
        </div>
        <div className="row" style={{marginTop: '.5rem'}}>
          <input value={input} onChange={e=>setInput(e.target.value)} placeholder="Digite sua mensagem..." style={{flex: 1}} onKeyDown={(e)=>{ if(e.key==='Enter') send() }} />
          <button onClick={send} disabled={loading}>{loading ? '...' : 'Enviar'}</button>
        </div>
        <small style={{opacity:.7}}>API: {API}</small>
      </div>
    </div>
  )
}
